TensorBoard event files were excluded from this archive to keep it small.
Regenerate them with:

    python scripts/train.py --policy ppo_lag --use-cbf \
        --init-from checkpoints/bc_warmstart_cbf.zip --normalize-reward \
        --run-name ppo_lag_cbf

then inspect with:

    tensorboard --logdir logs/tb_logs
