#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# 小海龟画彩虹螺旋节点（闭环反馈控制版）：turtle_rainbow_spiral_node
# 思路：角速度恒定 + 线速度递增 = 阿基米德螺旋线，每圈切换一次画笔颜色
#
# 与正方形实验的区别：本实验线速度随时间递增，形成螺旋轨迹；
# 通过调用 /turtle1/set_pen 服务实现彩虹颜色效果。

import math
import rospy
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
from turtlesim.srv import SetPen


class RainbowSpiralDrawer:
    """闭环反馈控制：小海龟绘制彩虹阿基米德螺旋线"""

    def __init__(self):
        # 初始化节点
        rospy.init_node('turtle_rainbow_spiral_node')
        # 发布者：把速度指令发到 /turtle1/cmd_vel 话题
        self.pub = rospy.Publisher('/turtle1/cmd_vel', Twist, queue_size=10)
        # 订阅者：实时接收 /turtle1/pose 话题上的位姿
        self.pose = None
        rospy.Subscriber('/turtle1/pose', Pose, self.pose_callback)
        # 50 Hz 闭环控制频率
        self.rate = rospy.Rate(50)

        # 螺旋参数
        self.max_radius = 4.0           # 最大半径 4.0 m
        self.angular_speed = 2.0        # 恒定角速度 2.0 rad/s
        self.initial_linear = 0.5       # 初始线速度 0.5 m/s
        self.linear_increment = 0.05    # 每周期线速度增量 0.05 m/s
        
        # 彩虹颜色表（RGB）
        self.colors = [
            (255, 0, 0),      # 红
            (255, 127, 0),    # 橙
            (255, 255, 0),    # 黄
            (0, 255, 0),      # 绿
            (0, 255, 255),    # 青
            (0, 0, 255),      # 蓝
            (139, 0, 255),    # 紫
        ]
        self.current_color_idx = 0
        self.pen_width = 3

        # 等待服务可用
        rospy.wait_for_service('/turtle1/set_pen')
        self.set_pen = rospy.ServiceProxy('/turtle1/set_pen', SetPen)

    def pose_callback(self, msg):
        """位姿回调：把最新位姿存下来"""
        self.pose = msg

    def publish_velocity(self, linear=0.0, angular=0.0):
        """组装并发布一条速度指令"""
        twist = Twist()
        twist.linear.x = linear
        twist.angular.z = angular
        self.pub.publish(twist)

    def wait_for_pose(self):
        """等第一帧位姿消息到来"""
        while self.pose is None and not rospy.is_shutdown():
            rospy.loginfo_throttle(1.0, "等待 /turtle1/pose 位姿数据...")
            self.rate.sleep()

    def set_pen_color(self, r, g, b, width=3, off=0):
        """设置画笔颜色和宽度"""
        try:
            self.set_pen(r, g, b, width, off)
        except rospy.ServiceException as e:
            rospy.logwarn("设置画笔失败: %s", e)

    def get_color_by_angle(self, theta):
        """根据当前角度计算颜色索引，每 2π 切换一次"""
        # 将角度归一化到 [0, 2π)
        normalized = theta % (2 * math.pi)
        # 每圈使用一种颜色
        color_idx = int(normalized / (2 * math.pi) * len(self.colors)) % len(self.colors)
        return color_idx

    def run(self):
        # 等位姿数据就绪
        self.wait_for_pose()
        
        # 记录螺旋中心（初始位置）
        center_x = self.pose.x
        center_y = self.pose.y
        rospy.loginfo("螺旋中心: (%.2f, %.2f)", center_x, center_y)

        # 设置初始画笔颜色（红色）
        r, g, b = self.colors[0]
        self.set_pen_color(r, g, b, self.pen_width, 0)
        rospy.loginfo("开始画彩虹螺旋，最大半径 %.1f 米", self.max_radius)

        start_time = rospy.Time.now().to_sec()
        current_radius = 0.0
        
        while not rospy.is_shutdown() and current_radius < self.max_radius:
            # 计算当前位置与中心的欧氏距离
            current_radius = math.hypot(self.pose.x - center_x, 
                                       self.pose.y - center_y)
            
            # 根据当前角度切换颜色
            color_idx = self.get_color_by_angle(self.pose.theta)
            if color_idx != self.current_color_idx:
                self.current_color_idx = color_idx
                r, g, b = self.colors[color_idx]
                self.set_pen_color(r, g, b, self.pen_width, 0)
                rospy.loginfo("切换到颜色 %d: RGB(%d, %d, %d)", 
                            color_idx, r, g, b)

            # 计算递增的线速度
            elapsed = rospy.Time.now().to_sec() - start_time
            linear_speed = self.initial_linear + self.linear_increment * elapsed
            
            # 发布速度指令：线速度递增 + 角速度恒定
            self.publish_velocity(linear=linear_speed, angular=self.angular_speed)
            self.rate.sleep()

        # 停止并抬笔
        self.publish_velocity()
        self.set_pen_color(0, 0, 0, self.pen_width, 1)  # 抬笔
        rospy.loginfo("彩虹螺旋画完啦！最终半径 %.2f 米", current_radius)


if __name__ == '__main__':
    node = RainbowSpiralDrawer()
    try:
        node.run()
    except rospy.ROSInterruptException:
        rospy.loginfo("节点被中断，让海龟停下来")
    finally:
        if not rospy.is_shutdown():
            node.publish_velocity()